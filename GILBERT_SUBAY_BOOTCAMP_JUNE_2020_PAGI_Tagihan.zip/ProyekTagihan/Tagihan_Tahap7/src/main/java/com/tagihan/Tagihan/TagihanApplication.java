package com.tagihan.Tagihan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TagihanApplication {

	public static void main(String[] args) {

		SpringApplication.run(TagihanApplication.class, args);
	}

}
